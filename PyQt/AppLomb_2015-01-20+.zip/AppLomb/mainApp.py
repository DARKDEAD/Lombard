__author__ = 'dead'

""" http://forum.vingrad.ru/forum/topic-274350.html """

#!/usr/bin/env python
import sys,sqlite3
from PyQt4 import QtCore, QtGui, uic
from windowEnter import startApp

if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    startApp()
    sys.exit(app.exec_())


